const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Create MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'your_password',
  database: 'testdb'
});

db.connect(err => {
  if (err) throw err;
  console.log('MySQL Connected...');
});

// Create Users table if not exists
db.query(`CREATE TABLE IF NOT EXISTS Users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(50),
  last_name VARCHAR(50),
  email VARCHAR(100),
  user_id VARCHAR(50),
  password VARCHAR(255)
)`, (err) => {
  if (err) throw err;
  console.log("Users table ready");
});

// POST route for registration
app.post('/register', (req, res) => {
  const { first_name, last_name, email, user_id, password } = req.body;

  if (!first_name || !last_name || !email || !user_id || !password) {
    return res.status(400).json({ error: "All fields are required" });
  }

  const sql = 'INSERT INTO Users (first_name, last_name, email, user_id, password) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [first_name, last_name, email, user_id, password], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "User registered successfully!", userId: result.insertId });
  });
});

app.listen(5000, () => console.log('Server running on http://localhost:5000'));
