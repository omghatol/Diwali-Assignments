import React, { useEffect, useState } from 'react';

const TodoList = () => {
  const [todos, setTodos] = useState([]);

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/todos")
      .then(res => res.json())
      .then(data => setTodos(data.slice(0, 10))) // first 10 items for brevity
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Todo List</h2>
      <ul className="grid gap-3">
        {todos.map(todo => (
          <li
            key={todo.id}
            className={`p-4 rounded-lg shadow ${todo.completed ? 'bg-green-100' : 'bg-red-100'}`}
          >
            <strong>{todo.title}</strong>
            <p>Status: {todo.completed ? "✅ Completed" : "❌ Pending"}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TodoList;
